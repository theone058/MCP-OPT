function u = sys_uopt(t, x, adj, p)
% ----------------------------------------------------------------

    y = p.ampl*t;
    dy = p.ampl;
       
    if p.c > 0
        % Calculation of input with regularization term
        u0 = adj*x / p.c;

        if u0 < p.umin
            u = p.umin;
        elseif u0 > p.umax
            u = p.umax;
        else 
            u = u0;
        end
    else
        % Calculation of optimal input without regularization term
        u0 = dy / (y-2*x);

        % Calculation of constraints
        if -adj*x > 1e-8|| (abs(adj*x)<1e-8 && u0 < p.umin)
            u = p.umin;
        elseif -adj*x < -1e-8|| (abs(adj*x)<1e-8 &&  u0 > p.umax)
            u = p.umax;
        else
            u = u0;
        end
    end
end