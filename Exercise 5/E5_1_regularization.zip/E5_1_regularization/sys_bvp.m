function [vec, sol, p] = sys_bvp(c, umin, umax)
% ----------------------------------------------------------------
    % System parameter
    % End time (optimization horizon)
    p.tf = 1.0;
    % Initial condition 
    p.x0 = 0.1;
    % Time derivative of the target state
    p.ampl = 0.5;
    
    % Penalty factor for regularization term in cost function
    p.c = c;
    
    % Save input constraints in the parameters
    p.umin = umin;
    p.umax = umax;

    % Options for bvp4c
    opt  = bvpset('Stats', 'on', 'RelTol', 1e-4, 'NMax', 10000);
    % Initial solution for states and adjoint states
    sol0 = bvpinit(linspace(0, p.tf, 100), [p.x0; 0]);
    % Call of bvp4c
    sol  = bvp4c(@sys_can_eq, @sys_bc, sol0, opt, p);
        
    % Save the optimal solution in vec
    vec.t   = linspace(0, p.tf, 100);
    vec.x   = interp1(sol.x, sol.y(1,:)', vec.t)';
    vec.adj = interp1(sol.x, sol.y(2,:)', vec.t)';
    % Calculation of the optimal input
    for i = 1 : length(vec.t)
      vec.u(i) = sys_uopt(vec.t(i), vec.x(i), vec.adj(i), p);
    end
   
end

function res = sys_bc(X0, Xf, p)
% ----------------------------------------------------------------
    % Boundary conditions for bvp4c
    x0 = X0(1);
    adjf = Xf(2);
    % Residuum
    res = [x0   - p.x0;
           adjf - 0];
end