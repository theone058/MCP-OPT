function f = sys_can_eq(t, X, p)
% ----------------------------------------------------------------
    x = X(1);
    adj = X(2);
    
    y = p.ampl*t;
    
    
    % Calculation of optimal input    
    u = sys_uopt(t, x, adj, p);
    
    % Canonical equations
    f = [-u*x;
         -2*(x-y)+adj*u];
end
