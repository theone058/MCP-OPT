% Numerical Optimization and Model Predictive Control
% Script for Task 5.1

% - complete the lines with '???'

umin = -5;
umax = 5;

c = ???

figure;
for i = 1:length(c)
    fprintf('----- Solution with c = %.0e: \n', c(i));
    [vec, sol, p] = sys_bvp(c(i), umin, umax);
    
    c_string = sprintf('c = %.0e', c(i));
    
    subplot(1, 3, 1);
    plot(vec.t, vec.x', 'DisplayName', c_string)
    hold on
    
    subplot(1, 3, 2);
    plot(vec.t, vec.u);
    hold on
    
    subplot(1, 3, 3);
    plot(vec.t, vec.adj);
    hold on
end

subplot(1, 3, 1);
plot(vec.t, p.ampl*vec.t, ':k', 'DisplayName', 'target');
xlabel('t');
ylabel('x')
legend( 'show')
