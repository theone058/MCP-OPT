classdef Crane2D_app_v7 < matlab.apps.AppBase

    properties (Access = public)
        UIFigure          matlab.ui.Figure
        CasesButtonGroup  matlab.ui.container.ButtonGroup
        noConstraintButton matlab.ui.control.RadioButton
        angleButton       matlab.ui.control.RadioButton
        parabolaButton    matlab.ui.control.RadioButton
        invertedVButton   matlab.ui.control.RadioButton
        ciclesButton      matlab.ui.control.RadioButton
        RunButton         matlab.ui.control.Button
        CompareButton     matlab.ui.control.Button
        UIAxes            matlab.ui.control.UIAxes

        X0Label           matlab.ui.control.Label
        X0EditField       matlab.ui.control.EditField
        XdesLabel         matlab.ui.control.Label
        XdesEditField     matlab.ui.control.EditField

        SolverLabel       matlab.ui.control.Label
        ThorLabel         matlab.ui.control.Label
        ThorEditField     matlab.ui.control.NumericEditField
        DtLabel           matlab.ui.control.Label
        DtEditField       matlab.ui.control.NumericEditField
        TsimLabel         matlab.ui.control.Label
        TsimEditField     matlab.ui.control.NumericEditField
        NhorLabel         matlab.ui.control.Label
        NhorEditField     matlab.ui.control.NumericEditField
        MaxGradIterLabel  matlab.ui.control.Label
        MaxGradIterEditField matlab.ui.control.NumericEditField
        MaxMultIterLabel  matlab.ui.control.Label
        MaxMultIterEditField matlab.ui.control.NumericEditField

        AngleLabel        matlab.ui.control.Label
        ThetaMaxLabel     matlab.ui.control.Label
        ThetaMaxEditField matlab.ui.control.NumericEditField
        OmegaMaxLabel     matlab.ui.control.Label
        OmegaMaxEditField matlab.ui.control.NumericEditField

        VLabel            matlab.ui.control.Label
        VC1Label          matlab.ui.control.Label
        VC1EditField      matlab.ui.control.NumericEditField
        VC2Label          matlab.ui.control.Label
        VC2EditField      matlab.ui.control.NumericEditField
        VSlopeLabel       matlab.ui.control.Label
        VSlopeEditField   matlab.ui.control.NumericEditField
        VEpsLabel         matlab.ui.control.Label
        VEpsEditField     matlab.ui.control.NumericEditField

        Circle1Label      matlab.ui.control.Label
        C11Label          matlab.ui.control.Label
        C11EditField      matlab.ui.control.NumericEditField
        C21Label          matlab.ui.control.Label
        C21EditField      matlab.ui.control.NumericEditField
        R1Label           matlab.ui.control.Label
        R1EditField       matlab.ui.control.NumericEditField

        Circle2Label      matlab.ui.control.Label
        C12Label          matlab.ui.control.Label
        C12EditField      matlab.ui.control.NumericEditField
        C22Label          matlab.ui.control.Label
        C22EditField      matlab.ui.control.NumericEditField
        R2Label           matlab.ui.control.Label
        R2EditField       matlab.ui.control.NumericEditField
    end

    properties (Access = private)
        % Per-case histories. Each case stores at most the last three runs.
        RunHistory = cell(1,5)
        MaxStoredRuns = 3

        % Physical times used for comparison snapshots [s].
        % Only times available in every compared run are used.
        % ComparisonTimes = [0, 1, 2, 3.5, 10]
        ComparisonTimes = [0, 1, 2, 3.5]
        
    end

    methods (Access = private)

        function caseNr = getSelectedCase(app)

            if app.noConstraintButton.Value
                caseNr = 1;
            elseif app.angleButton.Value
                caseNr = 2;
            elseif app.parabolaButton.Value
                caseNr = 3;
            elseif app.invertedVButton.Value
                caseNr = 4;
            elseif app.ciclesButton.Value
                caseNr = 5;
            else
                caseNr = 1;
            end

        end

        function x = parseStateVector(app, txt, name)

            txt = char(txt);
            txt = regexprep(txt, '[\[\],;]', ' ');
            x = sscanf(txt, '%f').';

            if numel(x) ~= 6
                error('%s must contain exactly 6 numbers.', name)
            end

        end

        function [x0, xdes] = getStateParams(app)

            x0   = parseStateVector(app, app.X0EditField.Value, 'x0');
            xdes = parseStateVector(app, app.XdesEditField.Value, 'xdes');

        end

        function [pAngle, pParabola, pV, pCircles] = getConstraintParams(app, caseNr)

            pAngle = [];
            pParabola = [];
            pV = [];
            pCircles = [];

            % Cases 2--5 all use angle and angular-velocity limits.
            if caseNr ~= 1
                % pAngle = [thetaMax, omegaMax]
                % thetaMax is converted from degrees to radians.
                pAngle = [
                    deg2rad(app.ThetaMaxEditField.Value), ...
                    app.OmegaMaxEditField.Value
                ];
            end

            switch caseNr
                case 3
                    % Hidden/default parabola parameters:
                    % pParabola = [a, b]
                    pParabola = [0.2, 1.25];

                case 4
                    % pV = [c1, c2, slope, eps]
                    pV = [
                        app.VC1EditField.Value, ...
                        app.VC2EditField.Value, ...
                        app.VSlopeEditField.Value, ...
                        app.VEpsEditField.Value
                    ];

                case 5
                    % pCircles = [c11, c21, r1, c12, c22, r2]
                    pCircles = [
                        app.C11EditField.Value, ...
                        app.C21EditField.Value, ...
                        app.R1EditField.Value, ...
                        app.C12EditField.Value, ...
                        app.C22EditField.Value, ...
                        app.R2EditField.Value
                    ];
            end

        end

        function [user, userparam, pParabola, pV, pCircles, Tsim] = buildUserStruct(app, caseNr)

            [x0, xdes] = getStateParams(app);
            [pAngle, pParabola, pV, pCircles] = ...
                getConstraintParams(app, caseNr);

            if app.ThorEditField.Value <= 0
                error('Thor must be greater than zero.')
            end

            if app.DtEditField.Value <= 0
                error('dt must be greater than zero.')
            end

            if app.TsimEditField.Value <= 0
                error('Tsim must be greater than zero.')
            end

            if app.NhorEditField.Value < 1
                error('Nhor must be at least 1.')
            end

            if app.MaxGradIterEditField.Value < 1
                error('MaxGradIter must be at least 1.')
            end

            if app.MaxMultIterEditField.Value < 1
                error('MaxMultIter must be at least 1.')
            end

            if caseNr ~= 1
                if app.ThetaMaxEditField.Value <= 0
                    error('The maximum angle must be greater than zero.')
                end

                if app.OmegaMaxEditField.Value <= 0
                    error('The maximum angular velocity must be greater than zero.')
                end
            end

            if caseNr == 4
                if app.VSlopeEditField.Value <= 0
                    error('The inverted-V slope must be greater than zero.')
                end

                if app.VEpsEditField.Value <= 0
                    error('The inverted-V smoothing epsilon must be greater than zero.')
                end
            end

            if caseNr == 5
                if app.R1EditField.Value <= 0 || app.R2EditField.Value <= 0
                    error('Both circle radii must be greater than zero.')
                end
            end

            % Hidden/default cost parameters
            pCost = [1.0, 2.0, 2.0, 1.0, 1.0, 4.0, 0.05, 0.05];

            % userparam is passed directly to grampc_init_Cmex.
            % Do not put userparam inside user.param.
            %
            % case 1 (no constraints):
            % userparam = [pCost]
            %
            % case 2 (angle and angular-velocity constraints):
            % userparam = [pCost, pAngle]
            %
            % case 3 (parabola + angle constraints):
            % userparam = [pCost, pAngle, pParabola]
            %
            % case 4 (inverted V + angle constraints):
            % userparam = [pCost, pAngle, pV]
            %
            % case 5 (circles + angle constraints):
            % userparam = [pCost, pAngle, pCircles]
            %
            % pAngle    = [thetaMax, omegaMax]
            % pParabola = [a, b]
            % pV        = [c1, c2, slope, eps]
            % pCircles  = [c11, c21, r1, c12, c22, r2]
            switch caseNr
                case 1
                    userparam = pCost;

                case 2
                    userparam = [pCost, pAngle];

                case 3
                    userparam = [pCost, pAngle, pParabola];

                case 4
                    userparam = [pCost, pAngle, pV];

                case 5
                    userparam = [pCost, pAngle, pCircles];
            end

            user = struct();

            % Initial values and setpoints of the states
            user.param.x0   = x0;
            user.param.xdes = xdes;

            % Initial values, setpoints and limits of the inputs
            user.param.u0   = [0.0, 0.0];
            user.param.udes = [0.0, 0.0];
            user.param.umax = [2.0, 2.0];
            user.param.umin = [-2.0, -2.0];

            % Time variables
            user.param.Thor = app.ThorEditField.Value;
            user.param.dt   = app.DtEditField.Value;
            user.param.t0   = 0.0;

            % Visible solver options
            user.opt.Nhor        = round(app.NhorEditField.Value);
            user.opt.MaxGradIter = round(app.MaxGradIterEditField.Value);
            user.opt.MaxMultIter = round(app.MaxMultIterEditField.Value);

            % Hidden/default options
            user.opt.TerminalCost = 'off';
            user.opt.AugLagUpdateGradientRelTol = 1e0;

            switch caseNr
                case 1
                    % No state/path constraints in case_1.

                case 2
                    % [theta+, theta-, omega+, omega-]
                    user.opt.ConstraintsAbsTol = ...
                        [1e-4, 1e-4, 1e-3, 1e-3];

                case {3, 4}
                    % [obstacle, theta+, theta-, omega+, omega-]
                    user.opt.ConstraintsAbsTol = ...
                        [1e-4, 1e-4, 1e-4, 1e-3, 1e-3];

                case 5
                    % [circle 1, circle 2, theta+, theta-, omega+, omega-]
                    user.opt.ConstraintsAbsTol = ...
                        [1e-4, 1e-4, 1e-4, 1e-4, 1e-3, 1e-3];
            end

            % Closed-loop simulation time, not a GRAMPC parameter
            Tsim = app.TsimEditField.Value;

        end

        function updateConstraintFieldsVisibility(app)

            % Angle and angular-velocity limits are active in cases 2--5.
            if app.noConstraintButton.Value
                angleVis = 'off';
            else
                angleVis = 'on';
            end

            app.AngleLabel.Visible = angleVis;
            app.ThetaMaxLabel.Visible = angleVis;
            app.ThetaMaxEditField.Visible = angleVis;
            app.OmegaMaxLabel.Visible = angleVis;
            app.OmegaMaxEditField.Visible = angleVis;

            if app.invertedVButton.Value
                vVis = 'on';
            else
                vVis = 'off';
            end

            app.VLabel.Visible = vVis;
            app.VC1Label.Visible = vVis;
            app.VC1EditField.Visible = vVis;
            app.VC2Label.Visible = vVis;
            app.VC2EditField.Visible = vVis;
            app.VSlopeLabel.Visible = vVis;
            app.VSlopeEditField.Visible = vVis;
            app.VEpsLabel.Visible = vVis;
            app.VEpsEditField.Visible = vVis;

            if app.ciclesButton.Value
                circleVis = 'on';
            else
                circleVis = 'off';
            end

            app.Circle1Label.Visible = circleVis;
            app.C11Label.Visible = circleVis;
            app.C11EditField.Visible = circleVis;
            app.C21Label.Visible = circleVis;
            app.C21EditField.Visible = circleVis;
            app.R1Label.Visible = circleVis;
            app.R1EditField.Visible = circleVis;

            app.Circle2Label.Visible = circleVis;
            app.C12Label.Visible = circleVis;
            app.C12EditField.Visible = circleVis;
            app.C22Label.Visible = circleVis;
            app.C22EditField.Visible = circleVis;
            app.R2Label.Visible = circleVis;
            app.R2EditField.Visible = circleVis;

        end

        function resetCaseDefaults(app, caseNr)

            % Common initial-state and solver defaults
            app.X0EditField.Value   = '[-2,0,2,0,0,0]';
            app.XdesEditField.Value = '[2,0,2,0,0,0]';

            app.ThorEditField.Value = 2.0;
            app.DtEditField.Value   = 0.002;
            app.TsimEditField.Value = 10.0;

            switch caseNr
                case 1  % No constraints
                    app.NhorEditField.Value        = 20;
                    app.MaxGradIterEditField.Value = 5;
                    app.MaxMultIterEditField.Value = 5;

                case 2  % Angle and angular-velocity limits
                    app.NhorEditField.Value        = 20;
                    app.MaxGradIterEditField.Value = 5;
                    app.MaxMultIterEditField.Value = 5;

                    app.ThetaMaxEditField.Value = 10.0;
                    app.OmegaMaxEditField.Value = 0.3;

                case 3  % Parabola
                    app.NhorEditField.Value        = 20;
                    app.MaxGradIterEditField.Value = 5;
                    app.MaxMultIterEditField.Value = 5;

                    app.ThetaMaxEditField.Value = 10.0;
                    app.OmegaMaxEditField.Value = 0.3;

                    % The parabola parameters remain hidden/default:
                    % pParabola = [0.2, 1.25].

                case 4  % Inverted V
                    app.NhorEditField.Value        = 20;
                    app.MaxGradIterEditField.Value = 5;
                    app.MaxMultIterEditField.Value = 5;

                    app.ThetaMaxEditField.Value = 10.0;
                    app.OmegaMaxEditField.Value = 0.3;

                    app.VC1EditField.Value    = 0.0;
                    app.VC2EditField.Value    = -1.1;
                    app.VSlopeEditField.Value = 0.5;
                    app.VEpsEditField.Value   = 1e-3;

                case 5  % Circles
                    app.NhorEditField.Value        = 50;
                    app.MaxGradIterEditField.Value = 8;
                    app.MaxMultIterEditField.Value = 8;

                    app.ThetaMaxEditField.Value = 10.0;
                    app.OmegaMaxEditField.Value = 0.3;

                    app.C11EditField.Value = -1.2;
                    app.C21EditField.Value = -1.7;
                    app.R1EditField.Value  = 0.35;

                    app.C12EditField.Value = 0.8;
                    app.C22EditField.Value = -2.0;
                    app.R2EditField.Value  = 0.30;

                otherwise
                    error('Unknown case number: %d', caseNr)
            end

        end

        function CasesButtonGroupSelectionChanged(app, event)

            caseNr = getSelectedCase(app);

            % Reset the newly selected case before showing its fields.
            % Clicking Run does not call this function, so modified values
            % can still be used for repeated runs and comparisons.
            resetCaseDefaults(app, caseNr)
            updateConstraintFieldsVisibility(app)
            updateCompareButton(app)


        end

        function setupAxes(app)

            ax = app.UIAxes;

            % cla(ax) does not remove graphics whose HandleVisibility is
            % 'off'. Comparison snapshots intentionally use that setting,
            % so they survived when another case was selected. Explicitly
            % delete every axes child before restoring the normal axes.
            legend(ax,'off')
            delete(allchild(ax))
            cla(ax,'reset')

            hold(ax,'on')
            grid(ax,'on')
            box(ax,'on')
            axis(ax,'equal')

            xlim(ax,[-2.5 2.5])
            ylim(ax,[-2.7 0.7])

            xlabel(ax,'s_1 [m]')
            ylabel(ax,'s_2 [m]')
            title(ax,'2D Crane MPC')

        end

        function setupSelectedCase_bck(app, caseNr)

            % Root folder = folder where this app .m file is located
            appRoot = fileparts(mfilename('fullpath'));
            mfilesPath = fullfile(appRoot, 'mfiles');
            srcPath    = fullfile(appRoot, 'src');

            % Add root and common GRAMPC MATLAB functions
            addpath(appRoot)

            if isfolder(mfilesPath)
                addpath(mfilesPath)
            else
                error('mfiles folder not found: %s', mfilesPath)
            end

            if exist('grampc_make_probfct', 'file') ~= 2
                error('grampc_make_probfct was not found in: %s', mfilesPath)
            end

            % Select the C problem file and its platform-specific MEX folder
            switch caseNr
                case 1
                    probfct = 'probfct_CRANE_2D_case_1.c';
                    mexFolderName = 'mex_case_1';
                    caseName = 'no constraints';

                case 2
                    probfct = 'probfct_CRANE_2D_case_2.c';
                    mexFolderName = 'mex_case_2';
                    caseName = 'angle constraints';

                case 3
                    probfct = 'probfct_CRANE_2D_case_3.c';
                    mexFolderName = 'mex_case_3';
                    caseName = 'parabola';

                case 4
                    probfct = 'probfct_CRANE_2D_case_4.c';
                    mexFolderName = 'mex_case_4';
                    caseName = 'inverted V';

                case 5
                    probfct = 'probfct_CRANE_2D_case_5.c';
                    mexFolderName = 'mex_case_5';
                    caseName = 'circles';

                otherwise
                    error('Unknown case number: %d', caseNr)
            end

            probfctRelativePath = fullfile('src', probfct);
            probfctPath = fullfile(appRoot, probfctRelativePath);
            selectedPath = fullfile(appRoot, mexFolderName);

            if ~isfile(probfctPath)
                error('Problem C file not found: %s', probfctPath)
            end

            % Remove all previously selected generated-MEX folders and the
            % old case folders from the MATLAB path. This prevents MATLAB
            % from loading binaries belonging to another scenario.
            for k = 1:5
                pathsToRemove = {
                    fullfile(appRoot, sprintf('mex_case_%d', k)), ...
                    fullfile(appRoot, sprintf('case_%d', k))
                };

                for j = 1:numel(pathsToRemove)
                    if contains(path, pathsToRemove{j})
                        rmpath(pathsToRemove{j})
                    end
                end
            end

            % Unload any MEX functions from the previously selected case.
            clear mex
            rehash

            % A directory alone is not sufficient: it may contain binaries
            % compiled for another operating system. Therefore, check for
            % the current platform's MEX extension as well.
            initMexFile = fullfile(selectedPath, ...
                ['grampc_init_Cmex.' mexext]);

            needsCompile = ~isfolder(selectedPath) || ~isfile(initMexFile);

            % Recompile automatically if the selected problem C file was
            % modified after the generated binaries.
            if ~needsCompile
                sourceInfo = dir(probfctPath);
                mexInfo = dir(initMexFile);
                needsCompile = sourceInfo.datenum > mexInfo.datenum;
            end

            if needsCompile
                app.RunButton.Text = sprintf('Compiling case %d...', caseNr);
                drawnow

                % mex_case_* contains generated files only. Remove an old or
                % incompatible folder before building a clean set of binaries.
                if isfolder(selectedPath)
                    rmdir(selectedPath, 's')
                end

                oldFolder = pwd;
                folderCleanup = onCleanup(@() cd(oldFolder));
                cd(appRoot)

                fprintf('Compiling case %d (%s) from %s\n', ...
                    caseNr, caseName, probfct)

                % Compile into mex_case_1, ..., mex_case_5.
                grampc_make_probfct(probfctRelativePath, mexFolderName)

                cd(oldFolder)
                clear folderCleanup
                clear mex
                rehash
            else
                fprintf('Using existing binaries for case %d (%s)\n', ...
                    caseNr, caseName)
            end

            if ~isfile(initMexFile)
                error(['Compilation did not create the expected MEX file: %s\n' ...
                       'Check the MATLAB MEX compiler configuration using mex -setup.'], ...
                       initMexFile)
            end

            % Put the selected platform-specific binaries first on the path.
            addpath(selectedPath, '-begin')
            rehash

            if exist('grampc_init_Cmex', 'file') ~= 3
                error('grampc_init_Cmex was not found after adding: %s', ...
                    selectedPath)
            end

            loadedMex = which('grampc_init_Cmex');
            if ~contains(loadedMex, selectedPath)
                error(['MATLAB loaded grampc_init_Cmex from the wrong folder:\n%s\n' ...
                       'Expected folder:\n%s'], loadedMex, selectedPath)
            end

            fprintf('Loaded case %d: %s\n', caseNr, caseName)

        end

        function setupSelectedCase(app, caseNr)

            % Root folder = folder where this app .m file is located
            appRoot   = fileparts(mfilename('fullpath'));
            mfilesPath = fullfile(appRoot, 'mfiles');
            srcPath    = fullfile(appRoot, 'src_cases');
            makePath   = fullfile(appRoot, 'make.m');
        
            % Put the app root and GRAMPC functions on the MATLAB path
            addpath(appRoot, '-begin')
        
            if isfolder(mfilesPath)
                addpath(mfilesPath, '-begin')
            else
                error('mfiles folder not found: %s', mfilesPath)
            end
        
            if ~isfolder(srcPath)
                error('src folder not found: %s', srcPath)
            end
        
            if ~isfile(makePath)
                error('make.m not found: %s', makePath)
            end
        
            if exist('grampc_make_probfct', 'file') ~= 2
                error('grampc_make_probfct was not found in: %s', mfilesPath)
            end
        
            % Check common GRAMPC binaries
        
            toolboxRebuilt = false;
        
            if grampcBinariesMissing(app, appRoot)
        
                app.RunButton.Text = 'Compiling GRAMPC...';
                drawnow
        
                oldFolder = pwd;
                folderCleanup = onCleanup(@() cd(oldFolder));
        
                cd(appRoot)
                clear mex
        
                fprintf('Compiling common GRAMPC binaries for %s...\n', ...
                    computer('arch'))
        
                make()
        
                clear mex
                rehash
        
                if grampcBinariesMissing(app, appRoot)
                    error(['make.m finished, but the expected object files for ' ...
                           'the current operating system were not created.'])
                end
        
                toolboxRebuilt = true;
        
                cd(oldFolder)
                clear folderCleanup
        
            end
        
            % Select case-specific C source and MEX folder
        
            switch caseNr
                case 1
                    probfct = 'probfct_CRANE_2D_case_1.c';
                    mexFolderName = 'mex_case_1';
                    caseName = 'no constraints';
        
                case 2
                    probfct = 'probfct_CRANE_2D_case_2.c';
                    mexFolderName = 'mex_case_2';
                    caseName = 'angle constraints';
        
                case 3
                    probfct = 'probfct_CRANE_2D_case_3.c';
                    mexFolderName = 'mex_case_3';
                    caseName = 'parabola';
        
                case 4
                    probfct = 'probfct_CRANE_2D_case_4.c';
                    mexFolderName = 'mex_case_4';
                    caseName = 'inverted V';
        
                case 5
                    probfct = 'probfct_CRANE_2D_case_5.c';
                    mexFolderName = 'mex_case_5';
                    caseName = 'circles';
        
                otherwise
                    error('Unknown case number: %d', caseNr)
            end
        
            probfctRelativePath = fullfile('src_cases', probfct);
            probfctPath = fullfile(appRoot, probfctRelativePath);
            selectedPath = fullfile(appRoot, mexFolderName);
        
            if ~isfile(probfctPath)
                error('Problem C file not found: %s', probfctPath)
            end
        
            % Remove other case-specific MEX folders from the MATLAB path
        
            for k = 1:5
                pathsToRemove = {
                    fullfile(appRoot, sprintf('mex_case_%d', k)), ...
                    fullfile(appRoot, sprintf('case_%d', k))
                };
        
                for j = 1:numel(pathsToRemove)
                    if contains(path, pathsToRemove{j})
                        rmpath(pathsToRemove{j})
                    end
                end
            end
        
            clear mex
            rehash
        
            % Check whether the selected case must be compiled
        
            initMexFile = fullfile(selectedPath, ...
                ['grampc_init_Cmex.' mexext]);
        
            % Recompile the case if:
            % - the common GRAMPC binaries were rebuilt,
            % - the case folder/current-OS MEX file is missing,
            % - or the problem C source is newer.
            needsCompile = toolboxRebuilt ...
                || ~isfolder(selectedPath) ...
                || ~isfile(initMexFile);
        
            if ~needsCompile
                sourceInfo = dir(probfctPath);
                mexInfo = dir(initMexFile);
        
                needsCompile = sourceInfo.datenum > mexInfo.datenum;
            end
        
            % Compile selected case when required
        
            if needsCompile
        
                app.RunButton.Text = sprintf('Compiling case %d...', caseNr);
                drawnow
        
                if isfolder(selectedPath)
                    rmdir(selectedPath, 's')
                end
        
                oldFolder = pwd;
                folderCleanup = onCleanup(@() cd(oldFolder));
        
                cd(appRoot)
        
                fprintf('Compiling case %d (%s) from %s\n', ...
                    caseNr, caseName, probfct)
        
                grampc_make_probfct( ...
                    probfctRelativePath, ...
                    mexFolderName)
        
                cd(oldFolder)
                clear folderCleanup
        
                clear mex
                rehash
        
            else
                fprintf('Using existing binaries for case %d (%s)\n', ...
                    caseNr, caseName)
            end
        
            % Verify and load the selected case
        
            if ~isfile(initMexFile)
                error(['Compilation did not create the expected MEX file:\n%s\n' ...
                       'Check the MATLAB compiler using mex -setup.'], ...
                       initMexFile)
            end
        
            addpath(selectedPath, '-begin')
            rehash
        
            if exist('grampc_init_Cmex', 'file') ~= 3
                error('grampc_init_Cmex was not found after adding: %s', ...
                    selectedPath)
            end
        
            loadedMex = which('grampc_init_Cmex');
        
            if ~contains(loadedMex, selectedPath)
                error(['MATLAB loaded grampc_init_Cmex from the wrong folder:\n%s\n' ...
                       'Expected folder:\n%s'], ...
                       loadedMex, selectedPath)
            end
        
            fprintf('Loaded case %d: %s\n', caseNr, caseName)
        
        end

        function [vec, grampc, pParabola, pV, pCircles] = runCraneMPC(app, caseNr)

            [user, userparam, pParabola, pV, pCircles, Tsim] = ...
                buildUserStruct(app, caseNr);

            % Direct GRAMPC initialization, no initData script
            grampc = grampc_init_Cmex(userparam);
            grampc = grampc_update_struct_grampc(grampc,user);

            if caseNr ~= 1
                [grampc, ~] = grampc_estim_penmin_Cmex(grampc,1);
            end

            odeopt = [];
            vec = grampc_init_struct_sol(grampc, Tsim);

            % Update the progress text about 100 times during the simulation.
            progressStep = max(1, floor(length(vec.t)/100));

            i = 1;

            while 1

                grampc = grampc_setparam_Cmex(grampc,'t0',vec.t(i));
                grampc = grampc_setparam_Cmex(grampc,'x0',vec.x(:,i));

                [grampc,vec.CPUtime(i)] = grampc_run_Cmex(grampc);

                vec = grampc_update_struct_sol(grampc, vec, i);

                if mod(i-1, progressStep) == 0 || i == length(vec.t)
                    app.RunButton.Text = sprintf('Running: %.2f / %.2f s', ...
                        min(vec.t(i), Tsim), Tsim);
                    drawnow
                end

                printed = grampc_printstatus_Cmex(grampc.sol.status,'Error');
                if printed
                    fprintf('at simulation time %f.\n --------\n', vec.t(i));
                end

                if i+1 > length(vec.t)
                    break;
                end

                [~,xtemp] = ode45(@grampc_ffct_Cmex, ...
                    vec.t(i)+[0 double(grampc.param.dt)], ...
                    vec.x(:,i), ...
                    odeopt, ...
                    vec.u(:,i), ...
                    vec.p(:,i), ...
                    grampc.param, ...
                    grampc.userparam);

                vec.x(:,i+1) = xtemp(end,:);

                if caseNr ~= 1
                    constr_i = grampc_ghfct_Cmex( ...
                        vec.t(i), ...
                        vec.x(:,i), ...
                        vec.u(:,i), ...
                        vec.p(:,i), ...
                        grampc.param, ...
                        grampc.userparam);

                    if ~isempty(constr_i)
                        vec.constr(:,i) = constr_i;
                    end
                end

                i = i + 1;

            end

            if isfield(vec, 'constr') && ~isempty(vec.constr)
                fprintf('\nMax constraint values:\n')
                for k = 1:size(vec.constr,1)
                    fprintf('h%d max = %.6e\n', k, max(vec.constr(k,:)));
                end
                fprintf('\n')
            end

        end

        function obstacle = makeObstacle(app, grampc, caseNr, pParabola, pV, pCircles)

            switch caseNr

                case {1, 2}
                    obstacle.s1 = [];
                    obstacle.s2 = [];

                case 3
                    a = pParabola(1);
                    b = pParabola(2);

                    obstacle.s1 = -2.5:0.01:2.5;
                    obstacle.s2 = -a*obstacle.s1.^2 - b;

                case 4
                    c1 = pV(1);
                    c2 = pV(2);
                    slope = pV(3);
                    epsV = pV(4);

                    obstacle.s1 = -2.5:0.01:2.5;
                    z = obstacle.s1 - c1;
                    obstacle.s2 = c2 - slope .* ...
                        (sqrt(z.^2 + epsV^2) - epsV);

                case 5
                    theta = linspace(0, 2*pi, 200);

                    c11 = pCircles(1);
                    c21 = pCircles(2);
                    r1  = pCircles(3);

                    c12 = pCircles(4);
                    c22 = pCircles(5);
                    r2  = pCircles(6);

                    obstacle.s1 = [
                        c11 + r1*cos(theta);
                        c12 + r2*cos(theta)
                    ];

                    obstacle.s2 = [
                        c21 + r1*sin(theta);
                        c22 + r2*sin(theta)
                    ];

            end

        end

        function animateCrane2D(app, vec, grampc, obstacle)

            ax = app.UIAxes;
        
            setupAxes(app)
        
            x0 = vec.x(:,1);
            xdes = grampc.param.xdes;
        
            s1_0 = x0(1) + x0(3)*sin(x0(5));
            s2_0 = -x0(3)*cos(x0(5));
        
            s1_des = xdes(1) + xdes(3)*sin(xdes(5));
            s2_des = -xdes(3)*cos(xdes(5));

            % Start and desired points
            plot(ax, s1_0, s2_0, 'ro', ...
                'MarkerFaceColor','r', ...
                'MarkerSize',8)

            text(ax, s1_0 + 0.08, s2_0 + 0.08, 'Start', ...
                'Color','r', ...
                'FontWeight','bold', ...
                'FontSize',11, ...
                'Clipping','on')
        
            plot(ax, s1_des, s2_des, 'go', ...
                'MarkerFaceColor','g', ...
                'MarkerSize',8)

            text(ax, s1_des + 0.08, s2_des + 0.08, 'End', ...
                'Color','g', ...
                'FontWeight','bold', ...
                'FontSize',11, ...
                'Clipping','on')
        
            steps = 150;
            idx = floor(linspace(1, size(vec.x,2), steps));
            x_temp = vec.x(:,idx);
        
            cc = get(ax,'ColorOrder');
        
            n_obs = size(obstacle.s1, 1);
        
            % Plot obstacles
            for n = 1:n_obs
                plot(ax, obstacle.s1(n,:), obstacle.s2(n,:), ...
                    'Color', cc(n,:), ...
                    'LineWidth', 1.5)
            end

            % Circle labels
            if n_obs == 2
                text(ax, app.C11EditField.Value, app.C21EditField.Value, 'Circle 1', ...
                    'Color', cc(1,:), ...
                    'HorizontalAlignment','center', ...
                    'VerticalAlignment','middle', ...
                    'FontWeight','bold', ...
                    'FontSize',11, ...
                    'Clipping','on')
        
                text(ax, app.C12EditField.Value, app.C22EditField.Value, 'Circle 2', ...
                    'Color', cc(2,:), ...
                    'HorizontalAlignment','center', ...
                    'VerticalAlignment','middle', ...
                    'FontWeight','bold', ...
                    'FontSize',11, ...
                    'Clipping','on')
            end
        
            % Draw crane snapshots
            for i = 1:size(x_temp,2)
                drawCrane2D(app, x_temp(:,i), 0.3+0.7/(steps+10)*i)
                drawnow
            end  

        end

        function drawCrane2D(app, x, color)

            ax = app.UIAxes;

            temp_color = [1-color, 1-color, 1-color];

            rectangle('Parent',ax, ...
                'Position',[x(1)-0.25 -0.1 0.5 0.2], ...
                'Curvature',0.2, ...
                'EdgeColor',temp_color)

            rectangle('Parent',ax, ...
                'Position',[x(1)-0.22 -0.12 0.08 0.08], ...
                'Curvature',[1 1], ...
                'EdgeColor',temp_color)

            rectangle('Parent',ax, ...
                'Position',[x(1)+0.14 -0.12 0.08 0.08], ...
                'Curvature',[1 1], ...
                'EdgeColor',temp_color)

            plot(ax, ...
                [x(1), x(1)+(x(3)-0.08)*sin(x(5))], ...
                [0,    -(x(3)-0.08)*cos(x(5))], ...
                'Color',temp_color)

            rectangle('Parent',ax, ...
                'Position',[x(1)+x(3)*sin(x(5))-0.04, ...
                            -x(3)*cos(x(5))+0.00, ...
                             0.08, 0.08], ...
                'Curvature',[1 1], ...
                'EdgeColor',temp_color)

        end

        function storeRunResult(app, caseNr, vec, grampc, obstacle)

            % Store only the data needed for visual comparison. This is much
            % lighter than keeping the complete GRAMPC solution structure.
            entry = struct();
            entry.t = vec.t;
            entry.x = vec.x;
            entry.xdes = grampc.param.xdes;
            entry.obstacle = obstacle;
            entry.description = makeRunDescription(app, caseNr);

            history = app.RunHistory{caseNr};

            if isempty(history)
                history = entry;
            else
                history(end+1) = entry;
            end

            % Keep only the newest MaxStoredRuns results.
            if numel(history) > app.MaxStoredRuns
                history = history(end-app.MaxStoredRuns+1:end);
            end

            app.RunHistory{caseNr} = history;
            updateCompareButton(app)

        end

        function description = makeRunDescription(app, caseNr)

            switch caseNr
                case 1
                    description = 'No constraints';

                otherwise
                    description = sprintf('theta=%.3g deg, omega=%.3g', ...
                        app.ThetaMaxEditField.Value, ...
                        app.OmegaMaxEditField.Value);
            end

        end

        function updateCompareButton(app)

            if isempty(app.CompareButton) || ~isvalid(app.CompareButton)
                return
            end

            caseNr = getSelectedCase(app);
            nRuns = numel(app.RunHistory{caseNr});

            if nRuns >= 2
                app.CompareButton.Visible = 'on';
                app.CompareButton.Enable = 'on';
                app.CompareButton.Text = sprintf('Compare runs (%d)', nRuns);
            else
                app.CompareButton.Visible = 'off';
                app.CompareButton.Enable = 'off';
                app.CompareButton.Text = 'Compare runs';
            end

        end

        function CompareButtonPushed(app, event)

            caseNr = getSelectedCase(app);
            history = app.RunHistory{caseNr};

            if numel(history) < 2
                updateCompareButton(app)
                return
            end

            app.RunButton.Enable = 'off';
            app.CompareButton.Enable = 'off';
            app.CompareButton.Text = 'Comparing...';
            drawnow

            try
                animateStoredRunsComparison(app, history)
            catch ME
                app.RunButton.Enable = 'on';
                updateCompareButton(app)
                rethrow(ME)
            end

            app.RunButton.Enable = 'on';
            updateCompareButton(app)

        end

        function animateStoredRunsComparison_bck(app, history)

            ax = app.UIAxes;
            setupAxes(app)

            nRuns = numel(history);
            latest = history(end);

            % Use the newest run for the common start/end annotations.
            x0 = latest.x(:,1);
            xdes = latest.xdes;

            s1_0 = x0(1) + x0(3)*sin(x0(5));
            s2_0 = -x0(3)*cos(x0(5));

            s1_des = xdes(1) + xdes(3)*sin(xdes(5));
            s2_des = -xdes(3)*cos(xdes(5));

            plot(ax, s1_0, s2_0, 'ro', ...
                'MarkerFaceColor','r', ...
                'MarkerSize',8, ...
                'HandleVisibility','off')

            text(ax, s1_0 + 0.08, s2_0 + 0.08, 'Start', ...
                'Color','r', ...
                'FontWeight','bold', ...
                'FontSize',11, ...
                'Clipping','on', ...
                'HandleVisibility','off')

            plot(ax, s1_des, s2_des, 'go', ...
                'MarkerFaceColor','g', ...
                'MarkerSize',8, ...
                'HandleVisibility','off')

            text(ax, s1_des + 0.08, s2_des + 0.08, 'End', ...
                'Color','g', ...
                'FontWeight','bold', ...
                'FontSize',11, ...
                'Clipping','on', ...
                'HandleVisibility','off')

            % Colors are ordered from oldest to newest. Older results are
            % blended with the axes background to imitate transparency.
            baseColors = [
                0.9290, 0.6940, 0.1250;
                0.8500, 0.3250, 0.0980;
                0.0000, 0.4470, 0.7410
            ];
            baseColors = baseColors(4-nRuns:3,:);

            backgroundColor = ax.Color;
            if nRuns == 2
                blend = [0.62, 1.00];
            else
                blend = [0.48, 0.70, 1.00];
            end

            runColors = zeros(nRuns,3);
            for k = 1:nRuns
                runColors(k,:) = blend(k)*baseColors(k,:) ...
                    + (1-blend(k))*backgroundColor;
            end

            % Previous obstacle geometries are shown only when they differ
            % from the newest one. The newest obstacle keeps the normal look.
            latestObstacle = latest.obstacle;
            for k = 1:nRuns-1
                oldObstacle = history(k).obstacle;
                if ~obstaclesAreEqual(app, oldObstacle, latestObstacle)
                    for n = 1:size(oldObstacle.s1,1)
                        plot(ax, oldObstacle.s1(n,:), oldObstacle.s2(n,:), '--', ...
                            'Color', runColors(k,:), ...
                            'LineWidth', 1.1, ...
                            'HandleVisibility','off')
                    end
                end
            end

            cc = get(ax,'ColorOrder');
            for n = 1:size(latestObstacle.s1,1)
                plot(ax, latestObstacle.s1(n,:), latestObstacle.s2(n,:), ...
                    'Color', cc(n,:), ...
                    'LineWidth', 1.5, ...
                    'HandleVisibility','off')
            end

            % Plot the complete trajectories once. Only these line handles
            % are passed to the legend, and legend auto-update is disabled.
            trajectoryHandles = gobjects(1,nRuns);
            for k = 1:nRuns
                xRun = history(k).x;
                s1 = xRun(1,:) + xRun(3,:) .* sin(xRun(5,:));
                s2 = -xRun(3,:) .* cos(xRun(5,:));

                if k == nRuns
                    lineStyle = '-';
                    lineWidth = 2.0;
                else
                    lineStyle = '--';
                    lineWidth = 1.7;
                end

                trajectoryHandles(k) = plot(ax, s1, s2, ...
                    'LineStyle', lineStyle, ...
                    'Color', runColors(k,:), ...
                    'LineWidth', lineWidth);
            end

            if nRuns == 2
                legendLabels = {'Previous run', 'Latest run'};
            else
                legendLabels = {'Oldest run', 'Previous run', 'Latest run'};
            end

            % Show the newest result first in the legend.
            legendOrder = nRuns:-1:1;
            lgd = legend(ax, trajectoryHandles(legendOrder), ...
                legendLabels(legendOrder), ...
                'Location','northeast', ...
                'Box','off');
            lgd.AutoUpdate = 'off';

            % Draw snapshots at the same physical times for every run.
            % This makes the parameter influence directly comparable even
            % when the stored runs use different sampling times or lengths.
            runStartTimes = arrayfun(@(r) r.t(1), history);
            runEndTimes = arrayfun(@(r) r.t(end), history);

            commonStart = max(runStartTimes);
            commonEnd = min(runEndTimes);

            comparisonTimes = [app.ComparisonTimes, app.TsimEditField.Value];
            comparisonTimes = comparisonTimes( ...
                comparisonTimes >= commonStart & ...
                comparisonTimes <= commonEnd);

            % Always include the common start and end times.
            comparisonTimes = unique([commonStart, comparisonTimes, commonEnd]);

            % Snapshot colors are deliberately lighter than the trajectory
            % colors so that the paths remain readable.
            if nRuns == 2
                snapshotBlend = [0.28, 0.42];
            else
                snapshotBlend = [0.20, 0.30, 0.42];
            end

            snapshotColors = zeros(nRuns,3);
            for k = 1:nRuns
                snapshotColors(k,:) = snapshotBlend(k)*baseColors(k,:) ...
                    + (1-snapshotBlend(k))*backgroundColor;
            end

            for k = 1:nRuns
                tRun = history(k).t(:);
                xRun = history(k).x.';

                % interp1 requires unique time samples.
                [tRun, uniqueIdx] = unique(tRun, 'stable');
                xRun = xRun(uniqueIdx,:);

                xSnapshots = interp1( ...
                    tRun, xRun, comparisonTimes, 'linear').';

                % Slightly separate labels when two or three runs have
                % snapshots at nearly the same cart position.
                labelYOffset = 0.06 * (k - (nRuns + 1)/2);

                for i = 1:numel(comparisonTimes)
                    drawComparisonCraneSnapshot(app, ...
                        xSnapshots(:,i), snapshotColors(k,:), ...
                        comparisonTimes(i), labelYOffset)
                end
            end

            drawnow

        end

        function animateStoredRunsComparison(app, history)

            ax = app.UIAxes;
            setupAxes(app)
        
            nRuns = numel(history);
            latest = history(end);
        
            % Use the newest run for the common start/end annotations.
            x0 = latest.x(:,1);
            xdes = latest.xdes;
        
            s1_0 = x0(1) + x0(3)*sin(x0(5));
            s2_0 = -x0(3)*cos(x0(5));
        
            s1_des = xdes(1) + xdes(3)*sin(xdes(5));
            s2_des = -xdes(3)*cos(xdes(5));
        
            plot(ax, s1_0, s2_0, 'ro', ...
                'MarkerFaceColor','r', ...
                'MarkerSize',8, ...
                'HandleVisibility','off')
        
            text(ax, s1_0 + 0.08, s2_0 + 0.08, 'Start', ...
                'Color','r', ...
                'FontWeight','bold', ...
                'FontSize',11, ...
                'Clipping','on', ...
                'HandleVisibility','off')
        
            plot(ax, s1_des, s2_des, 'go', ...
                'MarkerFaceColor','g', ...
                'MarkerSize',8, ...
                'HandleVisibility','off')
        
            text(ax, s1_des + 0.08, s2_des + 0.08, 'End', ...
                'Color','g', ...
                'FontWeight','bold', ...
                'FontSize',11, ...
                'Clipping','on', ...
                'HandleVisibility','off')
        
            % Colors are ordered from oldest to newest.
            baseColors = [
                0.9290, 0.6940, 0.1250;
                0.8500, 0.3250, 0.0980;
                0.0000, 0.4470, 0.7410
            ];
            baseColors = baseColors(4-nRuns:3,:);
        
            backgroundColor = ax.Color;
        
            if nRuns == 2
                blend = [0.62, 1.00];
            else
                blend = [0.48, 0.70, 1.00];
            end
        
            runColors = zeros(nRuns,3);
        
            for k = 1:nRuns
                runColors(k,:) = ...
                    blend(k)*baseColors(k,:) ...
                    + (1-blend(k))*backgroundColor;
            end
        
            % Plot old obstacle geometries only when they differ from the newest.
            latestObstacle = latest.obstacle;
        
            for k = 1:nRuns-1
                oldObstacle = history(k).obstacle;
        
                if ~obstaclesAreEqual(app, oldObstacle, latestObstacle)
                    for n = 1:size(oldObstacle.s1,1)
                        plot(ax, ...
                            oldObstacle.s1(n,:), ...
                            oldObstacle.s2(n,:), ...
                            '--', ...
                            'Color',runColors(k,:), ...
                            'LineWidth',1.1, ...
                            'HandleVisibility','off')
                    end
                end
            end
        
            % Plot newest obstacle normally.
            cc = get(ax,'ColorOrder');
        
            for n = 1:size(latestObstacle.s1,1)
                plot(ax, ...
                    latestObstacle.s1(n,:), ...
                    latestObstacle.s2(n,:), ...
                    'Color',cc(n,:), ...
                    'LineWidth',1.5, ...
                    'HandleVisibility','off')
            end
        
            % Plot complete trajectories.
            trajectoryHandles = gobjects(1,nRuns);
        
            for k = 1:nRuns
                xRun = history(k).x;
        
                s1 = xRun(1,:) + xRun(3,:) .* sin(xRun(5,:));
                s2 = -xRun(3,:) .* cos(xRun(5,:));
        
                if k == nRuns
                    lineStyle = '-';
                    lineWidth = 2.0;
                else
                    lineStyle = '--';
                    lineWidth = 1.7;
                end
        
                trajectoryHandles(k) = plot(ax, s1, s2, ...
                    'LineStyle',lineStyle, ...
                    'Color',runColors(k,:), ...
                    'LineWidth',lineWidth);
            end
        
            if nRuns == 2
                legendLabels = {'Previous run', 'Latest run'};
            else
                legendLabels = ...
                    {'Oldest run', 'Previous run', 'Latest run'};
            end
        
            % Show newest result first in the legend.
            legendOrder = nRuns:-1:1;
        
            lgd = legend(ax, ...
                trajectoryHandles(legendOrder), ...
                legendLabels(legendOrder), ...
                'Location','northeast', ...
                'Box','off');
        
            lgd.AutoUpdate = 'off';
        
            % Snapshot colors are lighter than trajectory colors.
            if nRuns == 2
                snapshotBlend = [0.28, 0.42];
            else
                snapshotBlend = [0.20, 0.30, 0.42];
            end
        
            snapshotColors = zeros(nRuns,3);
        
            for k = 1:nRuns
                snapshotColors(k,:) = ...
                    snapshotBlend(k)*baseColors(k,:) ...
                    + (1-snapshotBlend(k))*backgroundColor;
            end
        
            % Draw snapshots for every stored run.
            for k = 1:nRuns
        
                tRun = double(history(k).t(:));
                xRun = double(history(k).x.');
        
                % interp1 requires unique time samples.
                [tRun, uniqueIdx] = unique(tRun, 'stable');
                xRun = xRun(uniqueIdx,:);
        
                % Use the configured comparison times that exist in this run.
                runTimes = app.ComparisonTimes(:).';
        
                runTimes = runTimes( ...
                    runTimes >= tRun(1) & ...
                    runTimes < tRun(end));
        
                % Add this run's own initial and final simulation times.
                % Therefore, runs ending at 10 s and 15 s receive the correct
                % final snapshots and labels.
                runTimes = unique([tRun(1), runTimes, tRun(end)]);
        
                % Interpolate the state at this run's own snapshot times.
                xSnapshots = interp1( ...
                    tRun, ...
                    xRun, ...
                    runTimes, ...
                    'linear').';
        
                % Separate overlapping labels slightly between runs.
                labelYOffset = 0.06 * (k - (nRuns + 1)/2);
        
                for i = 1:numel(runTimes)
                    drawComparisonCraneSnapshot(app, ...
                        xSnapshots(:,i), ...
                        snapshotColors(k,:), ...
                        runTimes(i), ...
                        labelYOffset)
                end
            end
        
            drawnow
        
        end

        function drawComparisonCraneSnapshot(app, x, edgeColor, timeValue, labelYOffset)

            ax = app.UIAxes;

            rectangle('Parent',ax, ...
                'Position',[x(1)-0.25 -0.1 0.5 0.2], ...
                'Curvature',0.2, ...
                'EdgeColor',edgeColor, ...
                'LineWidth',0.75, ...
                'HandleVisibility','off')

            rectangle('Parent',ax, ...
                'Position',[x(1)-0.22 -0.12 0.08 0.08], ...
                'Curvature',[1 1], ...
                'EdgeColor',edgeColor, ...
                'LineWidth',0.75, ...
                'HandleVisibility','off')

            rectangle('Parent',ax, ...
                'Position',[x(1)+0.14 -0.12 0.08 0.08], ...
                'Curvature',[1 1], ...
                'EdgeColor',edgeColor, ...
                'LineWidth',0.75, ...
                'HandleVisibility','off')

            plot(ax, ...
                [x(1), x(1)+(x(3)-0.08)*sin(x(5))], ...
                [0,    -(x(3)-0.08)*cos(x(5))], ...
                'Color',edgeColor, ...
                'LineWidth',0.75, ...
                'HandleVisibility','off')

            rectangle('Parent',ax, ...
                'Position',[x(1)+x(3)*sin(x(5))-0.04, ...
                            -x(3)*cos(x(5)), ...
                             0.08, 0.08], ...
                'Curvature',[1 1], ...
                'EdgeColor',edgeColor, ...
                'LineWidth',0.75, ...
                'HandleVisibility','off')

            % Physical snapshot time shown directly above the trolley.
            text(ax, x(1), 0.14 + labelYOffset, ...
                sprintf('%g s', timeValue), ...
                'Color',edgeColor, ...
                'HorizontalAlignment','center', ...
                'VerticalAlignment','bottom', ...
                'FontSize',8, ...
                'FontWeight','bold', ...
                'Clipping','on', ...
                'HandleVisibility','off')

        end

        function equal = obstaclesAreEqual(app, obstacleA, obstacleB)

            if isempty(obstacleA) || isempty(obstacleB)
                equal = isempty(obstacleA) && isempty(obstacleB);
                return
            end

            if ~isfield(obstacleA, 's1') || ~isfield(obstacleA, 's2') || ...
                    ~isfield(obstacleB, 's1') || ~isfield(obstacleB, 's2')
                equal = false;
                return
            end

            if ~isequal(size(obstacleA.s1), size(obstacleB.s1)) || ...
                    ~isequal(size(obstacleA.s2), size(obstacleB.s2))
                equal = false;
                return
            end

            tolerance = 1e-12;
            equal = all(abs(obstacleA.s1(:)-obstacleB.s1(:)) <= tolerance) && ...
                    all(abs(obstacleA.s2(:)-obstacleB.s2(:)) <= tolerance);

        end

        function RunButtonPushed(app, event)

            app.RunButton.Enable = 'off';
            app.CompareButton.Enable = 'off';
            app.RunButton.Text = 'Preparing...';
            drawnow

            try
                caseNr = getSelectedCase(app);

                setupSelectedCase(app, caseNr)

                app.RunButton.Text = sprintf('Running: 0.00 / %.2f s', ...
                    app.TsimEditField.Value);
                drawnow

                [vec, grampc, pParabola, pV, pCircles] = ...
                    runCraneMPC(app, caseNr);

                obstacle = makeObstacle(app, grampc, caseNr, ...
                    pParabola, pV, pCircles);

                app.RunButton.Text = 'Animating...';
                drawnow

                % Every normal run keeps the original 150-frame animation.
                animateCrane2D(app, vec, grampc, obstacle)

                % Save the result after a successful run. Each case keeps
                % its own rolling history of at most three results.
                storeRunResult(app, caseNr, vec, grampc, obstacle)

            catch ME
                app.RunButton.Enable = 'on';
                app.RunButton.Text = 'Run';
                updateCompareButton(app)
                rethrow(ME)
            end

            app.RunButton.Enable = 'on';
            app.RunButton.Text = 'Run';
            updateCompareButton(app)

        end
        
        function needsBuild = grampcBinariesMissing(app, appRoot)

            binPath = fullfile(appRoot, 'bin');
        
            if ispc
                objectExtension = '.obj';
            else
                objectExtension = '.o';
            end
        
            requiredObjects = {
                'grampc_run'
                'grampc_init'
                'grampc_setopt'
                'grampc_run_Cmex'
                'grampc_init_Cmex'
                'grampc_ffct_Cmex'
                'grampc_ghfct_Cmex'
            };
        
            needsBuild = ~isfolder(binPath);
        
            if ~needsBuild
                for k = 1:numel(requiredObjects)
                    objectFile = fullfile( ...
                        binPath, ...
                        [requiredObjects{k}, objectExtension]);
        
                    if ~isfile(objectFile)
                        needsBuild = true;
                        break
                    end
                end
            end
        
        end
    
    end

    methods (Access = private)

        function createComponents(app)

            app.UIFigure = uifigure('Visible', 'off');
            app.UIFigure.Position = [100 100 980 680];
            app.UIFigure.Name = '2D Crane MPC Demo';

            app.UIAxes = uiaxes(app.UIFigure);
            app.UIAxes.Position = [290 80 650 520];

            title(app.UIAxes, '2D Crane MPC')
            xlabel(app.UIAxes, 's_1 [m]')
            ylabel(app.UIAxes, 's_2 [m]')

            app.UIAxes.XGrid = 'on';
            app.UIAxes.YGrid = 'on';
            app.UIAxes.Box = 'on';

            xlim(app.UIAxes,[-2.5 2.5])
            ylim(app.UIAxes,[-2.7 0.7])
            axis(app.UIAxes,'equal')

            app.CasesButtonGroup = uibuttongroup(app.UIFigure);
            app.CasesButtonGroup.Title = 'Cases';
            app.CasesButtonGroup.Position = [20 510 180 155];
            app.CasesButtonGroup.SelectionChangedFcn = createCallbackFcn(app, @CasesButtonGroupSelectionChanged, true);

            app.noConstraintButton = uiradiobutton(app.CasesButtonGroup);
            app.noConstraintButton.Text = 'no constraints';
            app.noConstraintButton.Position = [10 105 120 22];
            app.noConstraintButton.Value = true;

            app.angleButton = uiradiobutton(app.CasesButtonGroup);
            app.angleButton.Text = 'angle limits';
            app.angleButton.Position = [10 80 110 22];

            app.parabolaButton = uiradiobutton(app.CasesButtonGroup);
            app.parabolaButton.Text = 'parabola';
            app.parabolaButton.Position = [10 55 100 22];

            app.invertedVButton = uiradiobutton(app.CasesButtonGroup);
            app.invertedVButton.Text = 'inverted V';
            app.invertedVButton.Position = [10 30 100 22];

            app.ciclesButton = uiradiobutton(app.CasesButtonGroup);
            app.ciclesButton.Text = 'circles';
            app.ciclesButton.Position = [10 5 100 22];

            app.X0Label = uilabel(app.UIFigure);
            app.X0Label.Text = 'x0';
            app.X0Label.Position = [20 475 30 22];

            app.X0EditField = uieditfield(app.UIFigure, 'text');
            app.X0EditField.Position = [65 475 170 22];
            app.X0EditField.Value = '[-2,0,2,0,0,0]';

            app.XdesLabel = uilabel(app.UIFigure);
            app.XdesLabel.Text = 'xdes';
            app.XdesLabel.Position = [20 445 40 22];

            app.XdesEditField = uieditfield(app.UIFigure, 'text');
            app.XdesEditField.Position = [65 445 170 22];
            app.XdesEditField.Value = '[2,0,2,0,0,0]';

            app.SolverLabel = uilabel(app.UIFigure);
            app.SolverLabel.Text = 'Solver';
            app.SolverLabel.FontWeight = 'bold';
            app.SolverLabel.Position = [20 410 100 22];

            app.ThorLabel = uilabel(app.UIFigure);
            app.ThorLabel.Text = 'Thor';
            app.ThorLabel.Position = [20 385 90 22];

            app.ThorEditField = uieditfield(app.UIFigure, 'numeric');
            app.ThorEditField.Position = [150 385 85 22];
            app.ThorEditField.Value = 2.0;

            app.DtLabel = uilabel(app.UIFigure);
            app.DtLabel.Text = 'dt';
            app.DtLabel.Position = [20 360 90 22];

            app.DtEditField = uieditfield(app.UIFigure, 'numeric');
            app.DtEditField.Position = [150 360 85 22];
            app.DtEditField.Value = 0.002;

            app.TsimLabel = uilabel(app.UIFigure);
            app.TsimLabel.Text = 'Tsim';
            app.TsimLabel.Position = [20 335 90 22];

            app.TsimEditField = uieditfield(app.UIFigure, 'numeric');
            app.TsimEditField.Position = [150 335 85 22];
            app.TsimEditField.Value = 10.0;

            app.NhorLabel = uilabel(app.UIFigure);
            app.NhorLabel.Text = 'Nhor';
            app.NhorLabel.Position = [20 310 90 22];

            app.NhorEditField = uieditfield(app.UIFigure, 'numeric');
            app.NhorEditField.Position = [150 310 85 22];
            app.NhorEditField.Value = 20;

            app.MaxGradIterLabel = uilabel(app.UIFigure);
            app.MaxGradIterLabel.Text = 'MaxGradIter';
            app.MaxGradIterLabel.Position = [20 285 110 22];

            app.MaxGradIterEditField = uieditfield(app.UIFigure, 'numeric');
            app.MaxGradIterEditField.Position = [150 285 85 22];
            app.MaxGradIterEditField.Value = 5;

            app.MaxMultIterLabel = uilabel(app.UIFigure);
            app.MaxMultIterLabel.Text = 'MaxMultIter';
            app.MaxMultIterLabel.Position = [20 260 110 22];

            app.MaxMultIterEditField = uieditfield(app.UIFigure, 'numeric');
            app.MaxMultIterEditField.Position = [150 260 85 22];
            app.MaxMultIterEditField.Value = 5;

            app.AngleLabel = uilabel(app.UIFigure);
            app.AngleLabel.Text = 'Angle constraints';
            app.AngleLabel.FontWeight = 'bold';
            app.AngleLabel.Position = [20 235 130 22];

            app.ThetaMaxLabel = uilabel(app.UIFigure);
            app.ThetaMaxLabel.Text = 'theta max [deg]';
            app.ThetaMaxLabel.Position = [20 210 120 22];

            app.ThetaMaxEditField = uieditfield(app.UIFigure, 'numeric');
            app.ThetaMaxEditField.Position = [150 210 85 22];
            app.ThetaMaxEditField.Value = 10.0;

            app.OmegaMaxLabel = uilabel(app.UIFigure);
            app.OmegaMaxLabel.Text = 'omega max [rad/s]';
            app.OmegaMaxLabel.Position = [20 185 125 22];

            app.OmegaMaxEditField = uieditfield(app.UIFigure, 'numeric');
            app.OmegaMaxEditField.Position = [150 185 85 22];
            app.OmegaMaxEditField.Value = 0.3;

            % Inverted-V fields: two compact columns below angle limits.
            app.VLabel = uilabel(app.UIFigure);
            app.VLabel.Text = 'Inverted V';
            app.VLabel.FontWeight = 'bold';
            app.VLabel.Position = [20 155 100 22];

            app.VC1Label = uilabel(app.UIFigure);
            app.VC1Label.Text = 'c1';
            app.VC1Label.Position = [20 130 30 22];

            app.VC1EditField = uieditfield(app.UIFigure, 'numeric');
            app.VC1EditField.Position = [55 130 65 22];
            app.VC1EditField.Value = 0.0;

            app.VC2Label = uilabel(app.UIFigure);
            app.VC2Label.Text = 'c2';
            app.VC2Label.Position = [135 130 30 22];

            app.VC2EditField = uieditfield(app.UIFigure, 'numeric');
            app.VC2EditField.Position = [170 130 65 22];
            app.VC2EditField.Value = -1.1;

            app.VSlopeLabel = uilabel(app.UIFigure);
            app.VSlopeLabel.Text = 'slope';
            app.VSlopeLabel.Position = [20 105 35 22];

            app.VSlopeEditField = uieditfield(app.UIFigure, 'numeric');
            app.VSlopeEditField.Position = [55 105 65 22];
            app.VSlopeEditField.Value = 0.5;

            app.VEpsLabel = uilabel(app.UIFigure);
            app.VEpsLabel.Text = 'eps';
            app.VEpsLabel.Position = [135 105 30 22];

            app.VEpsEditField = uieditfield(app.UIFigure, 'numeric');
            app.VEpsEditField.Position = [170 105 65 22];
            app.VEpsEditField.Value = 1e-3;

            % Circle fields: circle 1 and circle 2 are displayed side by side.
            app.Circle1Label = uilabel(app.UIFigure);
            app.Circle1Label.Text = 'Circle 1';
            app.Circle1Label.FontWeight = 'bold';
            app.Circle1Label.Position = [20 155 90 22];

            app.C11Label = uilabel(app.UIFigure);
            app.C11Label.Text = 'c11';
            app.C11Label.Position = [20 130 30 22];

            app.C11EditField = uieditfield(app.UIFigure, 'numeric');
            app.C11EditField.Position = [55 130 65 22];
            app.C11EditField.Value = -1.2;

            app.C21Label = uilabel(app.UIFigure);
            app.C21Label.Text = 'c21';
            app.C21Label.Position = [20 105 30 22];

            app.C21EditField = uieditfield(app.UIFigure, 'numeric');
            app.C21EditField.Position = [55 105 65 22];
            app.C21EditField.Value = -1.7;

            app.R1Label = uilabel(app.UIFigure);
            app.R1Label.Text = 'r1';
            app.R1Label.Position = [20 80 30 22];

            app.R1EditField = uieditfield(app.UIFigure, 'numeric');
            app.R1EditField.Position = [55 80 65 22];
            app.R1EditField.Value = 0.35;

            app.Circle2Label = uilabel(app.UIFigure);
            app.Circle2Label.Text = 'Circle 2';
            app.Circle2Label.FontWeight = 'bold';
            app.Circle2Label.Position = [135 155 90 22];

            app.C12Label = uilabel(app.UIFigure);
            app.C12Label.Text = 'c12';
            app.C12Label.Position = [135 130 30 22];

            app.C12EditField = uieditfield(app.UIFigure, 'numeric');
            app.C12EditField.Position = [170 130 65 22];
            app.C12EditField.Value = 0.8;

            app.C22Label = uilabel(app.UIFigure);
            app.C22Label.Text = 'c22';
            app.C22Label.Position = [135 105 30 22];

            app.C22EditField = uieditfield(app.UIFigure, 'numeric');
            app.C22EditField.Position = [170 105 65 22];
            app.C22EditField.Value = -2.0;

            app.R2Label = uilabel(app.UIFigure);
            app.R2Label.Text = 'r2';
            app.R2Label.Position = [135 80 30 22];

            app.R2EditField = uieditfield(app.UIFigure, 'numeric');
            app.R2EditField.Position = [170 80 65 22];
            app.R2EditField.Value = 0.30;

            app.RunButton = uibutton(app.UIFigure, 'push');
            app.RunButton.Text = 'Run';
            app.RunButton.Position = [35 25 200 30];
            app.RunButton.ButtonPushedFcn = createCallbackFcn(app, @RunButtonPushed, true);

            app.CompareButton = uibutton(app.UIFigure, 'push');
            app.CompareButton.Text = 'Compare runs';
            app.CompareButton.Position = [740 25 200 30];
            app.CompareButton.Visible = 'off';
            app.CompareButton.Enable = 'off';
            app.CompareButton.ButtonPushedFcn = createCallbackFcn(app, @CompareButtonPushed, true);

            updateConstraintFieldsVisibility(app)
            updateCompareButton(app)

            app.UIFigure.Visible = 'on';

        end

    end

    methods (Access = public)

        function app = Crane2D_app_v7

            createComponents(app)

            registerApp(app, app.UIFigure)

            if nargout == 0
                clear app
            end

        end

        function delete(app)

            delete(app.UIFigure)

        end

    end

end
